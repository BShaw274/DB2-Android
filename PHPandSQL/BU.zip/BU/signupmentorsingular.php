<?php
$Email = $_POST['email'];
$meetingId = $_POST['meet_id'];

$response["success"] = "true";

//$Email = "student7@gmail.com";
//$meetingId = 100;


mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$dbConnection = new mysqli('localhost', 'root', '', 'db2');
if ($dbConnection->connect_error) {
  die("Connection failed: " . $dbConnection->connect_error);
}

//Portion of the code that gets the users ID from their email
  // get id
$stmt = $dbConnection->prepare("SELECT id FROM users Where email = ?");
if(false ===$stmt){
  //die('prepare() failed: ' . htmlspecialchars($mysqli->error));
  $response["success"] = "false";
    echo json_encode($response);
}
$check = $stmt->bind_param("s", $Email);
if(false ===$check){
  //die('bind_param() failed: ' . htmlspecialchars($stmt->error));
  $response["success"] = "false";
    echo json_encode($response);
}
$check = $stmt->execute();
if(false ===$check){
  //die('execute() failed: ' . htmlspecialchars($stmt->error));
    $response["success"] = "false";
    echo json_encode($response);
}
$studentId = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
//var_dump($studentId);

/*
This section is fetching different values from the database in order to check multiple things

This section acquires 5 different attributes

1. Selects the student grade level
2. Selects the meetings grade level
3. Selects the capacity of the meeting
4. Selects the amount of mentees already enrolled in the meeting
5. Selects the amount of mentors already enrolled in the meeting
*/

//grabbing the student's grade level
$stmt = $dbConnection->prepare("SELECT grade FROM students WHERE student_id = ?");
if(false ===$stmt){
  //die('prepare() failed: ' . htmlspecialchars($mysqli->error));
  $response["success"] = "false";
    echo json_encode($response);
}
$check = $stmt->bind_param("s", $studentId[0]['id']);
if(false ===$check){
  //die('bind_param() failed: ' . htmlspecialchars($stmt->error));
  $response["success"] = "false";
    echo json_encode($response);
}
$check = $stmt->execute();
if(false ===$check){
  //die('execute() failed: ' . htmlspecialchars($stmt->error));
    $response["success"] = "false";
      echo json_encode($response);
}
$studentGradeLevel = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
//var_dump($studentGradeLevel);
//getting the meeting grade level
$query = 'SELECT group_id FROM meetings WHERE meet_id=' . $meetingId;
$meetingGradeLevel = mysqli_query($dbConnection, $query);

$studentGrade = $studentGradeLevel[0]['grade'];


while ($row = mysqli_fetch_array ($meetingGradeLevel, MYSQLI_ASSOC)) {
  $meetingGrade = $row["group_id"];
  //echo $meetingGrade;
}

//getting the total capacity
$query =  'SELECT capacity FROM meetings WHERE meet_id= ' . $meetingId;
$meetingCapacity = mysqli_query($dbConnection, $query);
while ($row = mysqli_fetch_array ($meetingCapacity, MYSQLI_ASSOC)) {
  $meetingCapacityNum = $row["capacity"];
  //echo $meetingCapacityNum;
}

//getting the amount of mentees
$query = 'SELECT mentee_id FROM enroll WHERE meet_id= ' . $meetingId;
$menteeAmount = mysqli_query($dbConnection, $query);
$totalMentees = mysqli_num_rows($menteeAmount);
//echo $totalMentees;

//getting the amount of mentors
$query = 'SELECT mentor_id FROM enroll2 WHERE meet_id= ' . $meetingId;
$mentorAmount = mysqli_query($dbConnection, $query);
$totalMentors = mysqli_num_rows($mentorAmount);
//echo $totalMentors;

/*
This is where the students are actually being assigned to the specified meeting as the specified role

3 Major Checks are done here:
  1. Is the student in the same grade level?
  2. Is there room for another student based off the meeting's capacity?
  3. Can another student be assigned to mentees, the max for mentees is 6?

If these 3 checks pass then the student will be assigned into the meeting as a mentee.
*/
//check not already signed up for meeting
$stmt = $dbConnection->prepare("SELECT mentor_id FROM enroll2 Where meet_id = ?");
if(false ===$stmt){
die('prepare() failed: ' . htmlspecialchars($mysqli->error));
}
$check = $stmt->bind_param("s", $meetingId);
if(false ===$check){
  die('bind_param() failed: ' . htmlspecialchars($stmt->error));
}

$check = $stmt->execute();
if(false ===$check){
  die('execute() failed: ' . htmlspecialchars($stmt->error));
}
$EnrolledCheck = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
//var_dump($studentId);
$ICheck=0;
//echo $EnrolledCheck[0]["mentee_id"]." || ".$studentId[0]["id"];
$i=0;
//var_dump($studentId[0]['id']);
//var_dump($EnrolledCheck);
  if ($EnrolledCheck[0]["mentor_id"] == $studentId[0]['id']) {
    //echo"in";
    $response["success"] = "false";
    $ICheck=1;

    $response = array();
    $response[strval($i) . "cid"] = $studentId[0]['id'];
    $response[strval($i) . "cstatus"] = "Cannot Sign up, already signed up for the meeting";
    echo json_encode($response);
  }

//Check if they are int mentees
$stmt = $dbConnection->prepare("SELECT mentor_id FROM mentors Where mentor_id = ?");
if(false ===$stmt){
die('prepare() failed: ' . htmlspecialchars($mysqli->error));
}
$check = $stmt->bind_param("s", $studentId[0]['id']);
if(false ===$check){
  die('bind_param() failed: ' . htmlspecialchars($stmt->error));
}

$check = $stmt->execute();
if(false ===$check){
  die('execute() failed: ' . htmlspecialchars($stmt->error));
}
$InMentees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// time stuff
$timeError = FALSE;

$stmt = $dbConnection->prepare("SELECT time_slot_id, date from meetings where meet_id=?");
  if(false ===$stmt){
    die('prepare() failed: ' . htmlspecialchars($mysqli->error));
  }
  $check = $stmt->bind_param("s", $meetingId);
  if(false ===$check){
    die('bind_param() failed: ' . htmlspecialchars($stmt->error));
  }
  $check = $stmt->execute();
  if(false ===$check){
    die('execute() failed: ' . htmlspecialchars($stmt->error));
  }
  $timeSlotResult = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
   $stmt->close();
   //var_dump($timeSlotResult);

  //Checking time slots of other meetings student is currently in for mentee
   $stmt = $dbConnection->prepare("SELECT meet_id from enroll where mentee_id=?");
   if(false ===$stmt){
     die('prepare() failed: ' . htmlspecialchars($mysqli->error));
   }
   $check = $stmt->bind_param("s", $studentId[0]['id']);
   if(false ===$check){
     die('bind_param() failed: ' . htmlspecialchars($stmt->error));
   }
   $check = $stmt->execute();
   if(false ===$check){
     die('execute() failed: ' . htmlspecialchars($stmt->error));
   }
   $meetIdMentee = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();



    //Checking time slots of other meetings student is currently in for mentor
     $stmt = $dbConnection->prepare("SELECT meet_id from enroll2 where mentor_id=?");
     if(false ===$stmt){
       die('prepare() failed: ' . htmlspecialchars($mysqli->error));
     }
     $check = $stmt->bind_param("s", $studentId[0]['id']);
     if(false ===$check){
       die('bind_param() failed: ' . htmlspecialchars($stmt->error));
     }
     $check = $stmt->execute();
     if(false ===$check){
       die('execute() failed: ' . htmlspecialchars($stmt->error));
     }
     $meetIdMentor = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
      $stmt->close();

      //storing meetings you mentor and mentee in
     $allEnrolledId=array_merge($meetIdMentee, $meetIdMentor);
     //var_dump($allEnrolledId);
     //echo "||||||||||||||||||";

     //comparing timeslot of meeting you are trying to sign up for and meetings you are in
     for($j=0; $j<count($allEnrolledId); $j++){
       $stmt = $dbConnection->prepare("SELECT time_slot_id, date from meetings where meet_id=?");
       if(false ===$stmt){
         die('prepare() failed: ' . htmlspecialchars($mysqli->error));
       }
       $check = $stmt->bind_param("s", $allEnrolledId[$j]['meet_id']);
       if(false ===$check){
         die('bind_param() failed: ' . htmlspecialchars($stmt->error));
       }
       $check = $stmt->execute();
       if(false ===$check){
         die('execute() failed: ' . htmlspecialchars($stmt->error));
       }
       $checkTimeId = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
       $stmt->close();
       //var_dump($checkTimeId);
       if($timeSlotResult[0]['time_slot_id']==$checkTimeId[0]['time_slot_id'] && $timeSlotResult[0]['date']==$checkTimeId[0]['date']){
        //  echo "Cannot sign up for meeting because of time conflict with other meetings.";
        //  return;
        $timeError = TRUE;
       }

     }//Closing out for loop that checks times and dates to verify if student has time conflict




if($ICheck==0){
if($studentGrade > $meetingGrade){
  if(($totalMentees + $totalMentors) < $meetingCapacityNum){
    if($totalMentors < 3){
      if(!$timeError){
      //Inserting mentee Id and meeting Id into enroll

      // insert. into mentees if they are not in it
      if(empty($InMentees)){
        $stmt = $dbConnection->prepare("INSERT INTO mentors (mentor_id) VALUES (?)");
        if(false ===$stmt){
        die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
        $check = $stmt->bind_param("s",$studentId[0]['id']);
        if(false ===$check){
          die('bind_param() failed: ' . htmlspecialchars($stmt->error));
        }

        $check = $stmt->execute();
        if(false ===$check){
          die('execute() failed: ' . htmlspecialchars($stmt->error));
        }
      //enroll them into the meeting
      }
      $stmt = $dbConnection->prepare("INSERT INTO enroll2 (meet_id, mentor_id) VALUES (?,?)");
      if(false ===$stmt){
      die('prepare() failed: ' . htmlspecialchars($mysqli->error));
      }
      $check = $stmt->bind_param("ss", $meetingId, $studentId[0]['id']);
      if(false ===$check){
        die('bind_param() failed: ' . htmlspecialchars($stmt->error));
      }

      $check = $stmt->execute();
      if(false ===$check){
        die('execute() failed: ' . htmlspecialchars($stmt->error));
      }
      $response = array();
      $response[strval($i) . "cid"] = $studentId;
      $response[strval($i) . "cstatus"] = "Mentor was added to meeting";
      echo json_encode($response);
      //echo "Mentee was added to meeting";

      $stmt->close();
    }else{
      $response = array();
      $response[strval($i) . "cid"] = $studentId;
      $response[strval($i) . "cstatus"] = "This meeting is in time conflict with another meeting.";
      echo json_encode($response);
      //echo "This meeting already has enough mentees";
    }

    }else{
      $response = array();
      $response[strval($i) . "cid"] = $studentId;
      $response[strval($i) . "cstatus"] = "This meeting already has enough mentors";
      echo json_encode($response);
      //echo "This meeting already has enough mentees";
    }

  }else {
    $response = array();
    $response[strval($i) . "cid"] = $studentId;
    $response[strval($i) . "cstatus"] = "The meeting is already full";
    echo json_encode($response);
    //echo "The meeting is already full";
  }

}else{
  $response = array();
  $response[strval($i) . "cid"] = $studentId;
  $response[strval($i) . "cstatus"] = "Student is not above the grade level of the meeting";
  echo json_encode($response);
  //echo "Student is not in the same grade level as the meeting";
}
}

//echo "|||||||||||Var Dump Start";

//echo "Var Dump over|||||||||||";
/*
$response = array();
  //gets all the study material information

    for ($i = 0; $i < mysqli_num_rows($results); $i++){
      $query = "SELECT * FROM material WHERE material_id = {$materialIds[$i]}";
      $result = mysqli_query($dbConnection, $query);
      while($row = mysqli_fetch_assoc($result)){
        $response[strval($i) . "cid"] = $row['material_id'];
        $response[strval($i) . "cTitle"] = $row['title'];
        $response[strval($i) . "cAuthor"] = $row['author'];
        $response[strval($i) . "cType"] = $row['type'];
        $response[strval($i) . "cUrl"] = $row['url'];
        $response[strval($i) . "cAssigned_date"] = $row['assigned_date'];
        $response[strval($i) . "cNotes"] = $row['notes'];
      }
    }



    //var_dump($StudentsInfo);
    // get the child info that correspond to the student id's
    //$getUserInfo = "SELECT id, name, email, phone FROM users";
    //$infoRes = $mysqli->query($getUserInfo);
    //echo $i."|||";
  //var_dump($response);
// for close
//echo"||||||||||||End Result|||||||||";
echo json_encode($response);
*/
?>
